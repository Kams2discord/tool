# crowntool
Multi Tool (for now no more updates)

![Capture](https://user-images.githubusercontent.com/58895443/137584868-dc91342b-713a-4fe9-be1f-9d13c23bfe43.PNG)
## functions

- Discord Nitro Generator and inbuild Checker
- Discord Token Generator and Checker
- Discord Token Disabler
- Proxy Scraper
- Proxy Checker
- Pinger

## installing and use
```python
pip install -r requirements.txt
python crowntool.py
or just open the .py file
```

# INFO

I, the creator, am not responsible for any actions, and or damages, caused by this software.

You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only.

This software's main purpose is NOT to be used maliciously, or on any system that you do not own, or have the right to use.

By using this software, you automatically agree to the above.

if you have anything else i could add just tell me :)
